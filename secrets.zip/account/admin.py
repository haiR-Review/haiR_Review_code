from django.contrib import admin
from account.models import Profile
admin.site.register(Profile)
