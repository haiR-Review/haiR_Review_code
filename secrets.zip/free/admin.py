from django.contrib import admin

from .models import Free

# Register your models here.

admin.site.register(Free) 
